# AIPE 400 V to 200 V / 5 kW SiC synchronous buck - V2 design review

**AI-GENERATED ENGINEERING PROTOTYPE V2 - HUMAN REVIEW REQUIRED**

V2 is a CAD-complete two-board prototype: a routed 240 x 180 mm SiC power board and a routed 120 x 80 mm TMS320F28335 control board, both at zero native KiCad findings. Zero findings is a connectivity and rule statement, not engineering validation. No part was purchased, no board was fabricated, nothing was energised and no firmware exists. This report was written on 2026-10-11 from the files on branch `feat/sic-buck-5kw-v2` (last commit 99dfc01). Every number names the file it was read from; paths are relative to this directory. The release snapshot is described in section 12. Open review items LR-22, LR-24, LR-26, LR-27, LR-32 and LR-33 stay open (section 9); the authoritative open-items register is [known_issues.md](../verification/known_issues.md) (49 rows V2-01..V2-49 in four groups).

## 1. Specification and assumptions

The user fixed the converter, the controller and the CAD tool. Everything else is an agent assumption that a person must approve before any physical work.

| Item | Value | Source |
|---|---|---|
| User requirements | synchronous buck, non-isolated, common negative rail; 400 V in; 200 V / 25 A / 5 kW out; 50 kHz; Wolfspeed SiC MOSFET; TMS320F28335; KiCad; architecture AI-selected | [requirements.yaml](../input/requirements.yaml); `requirements_user` in [design_decisions.json](../design/design_decisions.json) |
| Unresolved user inputs | 14 entries left `null` by the task: input range, transient envelope, output tolerance, ripple targets, load-transient envelope, ambient, cooling, efficiency, aux supply, mechanics, PCB constraints, standards, firmware scope | `unresolved_user_inputs` in [requirements.yaml](../input/requirements.yaml) |
| Input range, UVLO, OVP, survival | 360-440 V; start 340 V / stop 320 V (run permit, auto-restart); input OVP 460 V latched; 480 V for 100 ms non-operating | `assumptions_accepted` in design_decisions.json; A-01..A-04 in [assumptions.md](../design/assumptions.md) |
| Switch-node allowance | 90 V overshoot, 530 V recurring peak at 440 V | same; A-41 |
| Output | +/-1 % static (198-202 V); <= 2.0 Vpp ripple; output OVP 230 V latched (CR-04) | same; A-08, A-09, A-44 |
| Input DC-link ripple | <= 2 % pk-pk (8 Vpp at 400 V) | same; A-42 |
| Overload and transients | 27.5 A for 10 s; 12.5 A step <= 10 V, recovery <= 5 ms; 25 A dump must stay below the 230 V OVP (computed 215-218 V) | same; A-10, A-11, A-43 |
| Control and ripple target | voltage-loop crossover 2.0-2.5 kHz with an inner current loop; inductor ripple 30 % of I_o at 400 V | same; A-11, A-13 |
| Thermal | ambient 0-50 C; T_J design limit 150 C, preferred 125 C; forced air over a shared PE-bonded heatsink with rated insulating pads; inductor in the same fan stream | same; A-18, A-19 |
| Efficiency | 98.0 % target, 97.5 % acceptance floor at 400 V / 25 A | same; A-20 |
| Auxiliary | external regulated 12 V +/-10 %, 2.0 A minimum, 2.5 A recommended; fan and relay coil inside the budget | same; A-22 |
| Insulation basis | OVC II, PD2, <= 2000 m; impulse 4 kV basic / 6 kV reinforced (600 V-system row; the 2.5 kV reading of a 300 V system is a recorded conflict); SELV control domain with a PROPOSED single-point SGND-to-PE bond (PELV deviation, A-23) | same; A-21, A-23, A-25..A-27 |
| Source and load | regulated bus or current-limited supply, 18-25 A limit, no hot-plug; resistor or CC/CR load, no regeneration; firmware input-current limit 15.6 A below 360 V (CR-20) | same; A-05, A-07, A-12 |

The register in [assumptions.md](../design/assumptions.md) classes every value as U (user), S (accepted seed), S\* (corrected seed), D (derived) or H (human review); its section 7 lists the human-review items (impulse basis, 9.0 mm rule, PELV bond, pad rating, OTP ladder, efficiency floor, fuse I2t, DESAT margin). [v1_v2_comparison.md](v1_v2_comparison.md) counts 49 register rows against 13 in V1. The baseline `design_decisions.json` (schema 4) records 26 conflict resolutions CR-01..CR-26 and 13 open items for human review.

## 2. Design and calculations

All values are first-order analytical estimates from `python -m automation.scripts.calculate_sic_buck`; nothing in this section is simulated or measured ([calculations.md](../design/calculations.md), [calculations.json](../design/calculations.json)).

| Quantity | Value | Source |
|---|---|---|
| Duty ratio | 0.556 / 0.500 / 0.455 at 360 / 400 / 440 V | calculations.md section 2 |
| Input current at 98 % | 14.17 / 12.76 / 11.60 A at 25 A; 15.59 / 14.03 / 12.76 A at 27.5 A | section 2 |
| Inductance of the real choke | 319 / 272 / 263 / 208 uH at 0 / 25 / 27.5 / 41 A nominal (baseline rounds the last to 210); 240 uH at 25 A with AL -8 % and the datasheet-minimum curve | section 6 |
| Inductor ripple | 6.52 / 7.34 / 8.01 App nominal at 25 A; 7.42 / 8.34 / 9.10 App worst; baseline target 30 % (7.3 App = 29 %) | section 2; A-13 |
| Peak current | 28.26-29.00 A at 25 A; 30.88-31.65 A at 27.5 A; 32.01 A worst (440 V / 27.5 A, AL -8 %) | section 2 |
| MOSFET pair loss, T_J 150 C, typical R | 46.8 / 48.1 / 49.5 W at k_RG 1.3 (25 A); 54.9-57.9 W at 27.5 A; up to 64.3 W at k_RG 2.0 | section 3 |
| Hottest high-side device | 35.0 W (360 V / 27.5 A, max-R 57.2 mohm, k_RG 1.3); 40.4 W at k_RG 2.0 | section 3; baseline CR-21 uses 34.1 W |
| Dead time (CR-07) | requirement 95 ns, x1.5 = 142.5, adopted minimum 150 ns; programmed 300 ns = 45 ticks of 6.667 ns; 265 ns after 35 ns erosion; target 250 ns; upper bound 400 ns; 1.2 W per 100 ns | `dead_time` in calculations.json |
| DESAT (CB-GD-001 network) | V_DS trip 3.59 V (3.17-4.01); trip current 52-85 A at 175 C (46 A absolute minimum at minimum V_trip and maximum R_DS(on)); blanking 252 / 287 / 326 ns; response 0.55 / 0.77 / 1.07 us against a 1.5 us budget | section 5 |
| Thermal budget | T_sink 64.0-71.3 C; T_J,HS 111.9 C at 400 V / 25 A typical, 143.1 C at the hottest corner (360 V / 27.5 A, max-R, k_RG 2.0); P_max 41.5 W per device (KR-TH-001), margin 1.18x over 35.0 W | section 9; baseline CR-21 states 1.22x over 34.1 W |
| Efficiency roll-up at 400 V / 25 A | typical 98.70 % converter-only, 98.55 % with aux electronics, 98.38 % system (relay hold, fan); bounded worst 98.27 % / 98.12 % / 97.96 % | section 12 |
| Invariants | 19 asserted, all PASS: e.g. T_J,HS 143.1 < 150 C; discharge to 60 V in 20.3 s (< 60 s); 12.5 A step 9.23 V (< 10 V at 2.0 kHz); input ripple 0.98 % (< 2 %); OC lower bound 33.7 A > 32.0 A worst peak | `invariants` in calculations.json |

The script lists nine limitations: switching-energy scaling about +/-30 % plus the k_RG range 1.3-2.0 (graph read), E_rr uncertain by about a factor of two, heatsink data at distributor level, R_DS(on) at 150 C interpolated, pad resistance 1.4 K/W to be measured, MLCC DC bias assumed ([calculations.md](../design/calculations.md) section 16). The thermal document adds that the 125 C preference is not met at the max-R overload corner and that a fan stall drives T_J above 175 C in steady state, so the OTP is mandatory ([thermal_analysis.md](../design/thermal_analysis.md) sections 3 and 5).

## 3. Architecture chosen and alternatives

Option B was chosen: a power board carrying the devices, drivers, three bias modules, DC link, inductor, output bank, all eight barrier parts and the fast protection, plus a SELV control board stacked on the power board's SELV strip through a 2 x 25 mezzanine ([architecture.md](../design/architecture.md) section 1). The weighted scores are A 2.75 / B 4.00 / C 3.10, and B leads in all five sensitivity sets by at least 0.37 ([architecture_comparison.md](architecture_comparison.md) section 5).

| Option | Boards | Why not chosen / chosen |
|---|---|---|
| A, integrated | one 240 x 204 mm board, 70 um on every layer | repeats V1-09: a 0.5 mm pitch LQFP-176 on 2 oz outer copper has a 0.22 mm gap with 10 % margin and no solder-mask dam (architecture_comparison.md section 4) |
| B, two boards (chosen) | power 240 x 180 mm, 4 x 70 um, 2.0 mm; control 120 x 80 mm, 4 x 35 um, 1.6 mm | one barrier line on one board (KR-ISO-001), fine-pitch part on 35 um copper, bench PWM drive of the power stage at the mezzanine |
| C, plug-in driver cards | as B plus two 50 x 30 mm driver cards | adds a connector inside each gate loop and a barrier instance per card; no programme use for the modularity (section 8) |

Residual risks of B recorded for review: the single-ended mezzanine link in a 400 V / 50 kHz environment, the stacked-board through-air clearance at PD2, and an HV zone utilisation of 99-119 % of the 33,600 mm2 HV area with the baseline heatsink reservation (CR-22; architecture_comparison.md sections 3 and 9). The placed board met the 240 x 180 mm target (section 7).

## 4. Power stage and component selection

The power semiconductor is one Wolfspeed C4MS025120K (1200 V, TO-247-4 Kelvin source) per position. Utilisation is 42-46 % of 1200 V at the 440 V corner with 62-88 V overshoot and 49 % even at 150 V overshoot; the current margins are 3.0x on I_D at 100 C and 8.5-8.7x on I_DM (274 A; component_selection.md section 2 states 8.7x against I_pk, [calculations.md](../design/calculations.md) section 3 states 8.5x against the 32.0 A worst peak); P_max 41.5 W against 34.1 W (1.22x). The 650 V class was rejected at 77-84 % utilisation; C3M0021120K (+8 W) is the pin-compatible fallback because C4MS025120K stock is Arrow-only with a 13-week lead elsewhere ([component_selection.md](../design/component_selection.md) section 2). Wolfspeed publishes no short-circuit withstand time, so KR-PR-001 is closed only by a destructive test.

| Block | Selection and margin | Source |
|---|---|---|
| DC-link films | 2 x TDK B32776G8206K000 20 uF 800 V; 0.55 / 0.575 / 0.60 of V_R at 440 / 460 / 480 V; 6.92 A per part against 14.5 A; realised ripple 3.94 Vpp (0.98 %) at 27.5 A | component_selection.md section 5; calculations.md section 7 |
| HV ceramic tier | 10 x TDK CGA9P1X7T2J474M250KC 0.47 uF 630 V 2220; 1.88 uF effective assumed (60 % DC-bias loss, curve not fetched) against 1.5 uF required; film-to-ceramic ring about 1.1 W | same |
| Output films | 2 x TDK B32776G4606K000 60 uF 450 V; 1.43 A per part against 23.5 A; 0.25 Vpp ripple; 12.5 A step 7.4 V (2.5 kHz) / 9.2 V (2.0 kHz); 25 A dump 214.8-218.5 V below the 230 V OVP | same |
| Inductor L1 | custom record AIPE-MAG-L1-SICBUCK-5KW-V2, status `designed_not_built`: 2 x Magnetics 0058192A2 High Flux 60u stacked, 34 T AWG 10; 272 uH at 25 A; vendor-style I_sat 37.3 A nominal / about 35 A worst; 16.4 W at 400 V / 25 A, 23-26 W bounded; 632 g bare; potted cup about 72 x 46 mm; forced air mandatory (CR-14), 3-stack fallback | [magnetic_record.json](../components/magnetic_record.json); component_selection.md section 4 |
| Precharge, relay, fuse | PTC across the relay contacts, part to be re-selected (CR-19; tau 5.8 ms with the placeholder R); Omron G9EA-1 DC12 bypass relay, 400 V maximum switching voltage, never opened under load; Littelfuse KLKD025.T 25 A 600 VDC off-board, loading 57 % at 360 V / 25 A, 70 % at 320 V / 27.5 A (CR-15), melting I2t not found | component_selection.md section 8; calculations.md section 11 |
| Bleeders and indicators | input 3 x 120 k 2512, output 2 x 100 k 2512 plus LED chains (CR-03); both banks below 60 V in 20.3 s with the merged networks, 36.5 s with the bleeder chains alone; standby 1.37 W | calculations.md section 7 |
| HV terminals, PE | 6 x Wuerth REDCUBE THR M5 74651195 (CR-10); M4 PE stud; PGND-to-PE link, 2 x 1 M 500 V and Y2 pads all DNP (A-23) | component_selection.md section 8 |

The purchasing BOMs list 237 power-board and 207 control-board references (444 merged rows), of which 196 and 186 are purchased parts and 16 and 1 are DNP ([bom_power.csv](../components/bom_power.csv), [bom_control.csv](../components/bom_control.csv), [bom.csv](../components/bom.csv); counts in [verification-summary.json](../verification/verification-summary.json)). [component_records.json](../components/component_records.json) holds 65 part-type records with per-part verification levels; [v1_v2_comparison.md](v1_v2_comparison.md) counts 29 at fetched-datasheet, 7 search-snippet, 3 manufacturer-page and 26 unverified. Hardware, the heatsink, pads, the winding house and the potting cup are not a completed mechanical BOM.

## 5. Gate driver, bias, protection and sensing

| Function | Values as designed | Source |
|---|---|---|
| Isolated driver | 2 x UCC21710-Q1 (5.7 kVrms, 2121 VDC working, CMTI > 150 V/ns); +15 V / -4 V gate rails; R_G,on 10 ohm at bring-up (6.8 ohm target), R_G,off 3.3 ohm; active Miller clamp required (charge-based off-state excursion 0-3 V margin to V_GS(th) 2.0 V); IN+/IN- interlock (KR-GD-009) | component_selection.md section 3; calculations.md section 3 |
| DESAT | R1 2.2 k, R2 4.99 k, R3 1.0 k, 680 pF, US1M diode; V_DS trip 3.6 V (3.2-4.0 V); 52-85 A at 175 C (46 A absolute minimum at minimum V_trip and maximum R_DS(on)); false-trip margin 1.34-1.65x at overload; response 0.55-1.07 us; soft turn-off peak about 687 V at 460 V / 35 nH | calculations.md section 5 |
| Bias (CR-12) | 3 x UCC14141-Q1: gate modules VDD-VEE 19.0 V / COM-VEE 4.0 V; sensing module 15.0 V / 5.0 V with VEE = PGND; load 21 / 21 / 27 % of the 1.5 W rating; three modules draw 0.29 A at 12 V; RLIM <= 470 ohm and the COM-VEE sourcing feasibility are human-review items | calculations.md section 4 |
| 12 V budget (CR-02) | TPS26400 eFuse, R_ILIM 6.04 k -> I_CB about 1.96 A, UVLO 10.0 / 9.3 V, OVP 14.45 / 13.4 V; 1.76 A worst at relay pull-in, 1.59 A steady (margins 1.11x / 1.23x); zero margin against an assumed -10 % I_CB minimum | architecture.md section 5; calculations.json `open_items` |
| Current sensing and OC | TMCS1133C2A, 0.33 V + 0.050 V/A, full scale 53.4 A, 14.65 mA/LSB; OC 37.5 A from V_OC 0.750 V (REF3125, 2.32 k / 1.00 k); trip band 33.7-41.2 A worst; chain 546 ns; worst trip peak about 42.6 A at 175 uH (CR-05) | calculations.md section 8 |
| Voltage sensing | AMC1311B x 2; V_IN ladder 4 x 750 k + 10.0 k (full scale 602 V, 147 mV/LSB); V_OUT ladder 2 x 750 k + 10.0 k (302 V, 73.7 mV/LSB); OPA2320 difference stages on the power-board SELV strip (CR-16) | calculations.md section 8; architecture.md section 2.4 |
| Comparators | OVP_in 459.9 V (1.00 k / 11.0 k); OVP_out 229.8 V (953 ohm / 10.0 k, CR-04); UVLO 339.1 / 319.5 V (asymmetric hysteresis: simulate or move to firmware) | calculations.md section 8 |
| NTC and OTP (CR-25) | Vishay NTCALUG01A103F on the sink top face, 2.2 k pull-up to the 3.00 V REF3130 (CR-26); ladder 80 C derate / 90 C firmware trip / 100 C hardware trip = 1.086 / 0.881 / 0.710 V; hardware divider 32.4 k / 10.0 k = 0.7075 V; T_J,HS about T_NTC + 50-66 K at full load, so a 100 C sink maps to T_J,HS 150-166 C (KR-TH-003 review item) | calculations.md section 8; thermal_analysis.md section 6 |
| Fault logic (CR-17, CR-26) | 13 latched active-low inputs AND-combined by 3 x SN74LV21A with SN74LV04A inverters into the SN74LVC1G74 latch; run-permit group UVLO_N, RDY_H, RDY_L, ARMED; fault-to-gate-off about 234-240 ns plus source delay; restart only on a new ARM edge | architecture.md section 6 |

## 6. Control board

The control board carries the TMS320F28335PGFA with all 176 pins mapped ([tms320f28335_pgf_pins.csv](../components/tms320f28335_pgf_pins.csv)), a 30 MHz oscillator, 14-pin JTAG, 3.3 V UART and boot straps GPIO84-87; supplies are TPS26400 -> TPS54302 5 V -> TPS767D301 1.9 V and 3.3 V with a TPS3808G01 at 4.5 V (CR-18) ([architecture.md](../design/architecture.md) section 2.5). The firmware contract defines ePWM1 up-down count, TBPRD 1500 at 150 MHz, dead band 45 ticks, duty ceiling 0.85, trip zones TZ1-TZ4 on GPIO12-15, the ADC map (VIN_SENSE A0, ISENSE A1, TEMP_HS_NTC A2, TEMP_CTRL A3, ISENSE_REF A4, I12V_MON B0, VOUT_SENSE B1, V12V_MON B3) and a ten-step start-up sequence ([firmware_interface.md](../design/firmware_interface.md) sections 1-3). No firmware was written, simulated or tested; its first-order phase budget gives 14-47 deg of margin depending on single or double update and the sense filters (section 9 of that document).

Mezzanine highlights (Samtec SSW-125-01-G-D socket on the power board, TSW-125-07-G-D header on the control board; baseline `interconnect.pin_assignment`, [architecture.md](../design/architecture.md) section 4):

| Pins | Nets | Note |
|---|---|---|
| 1-3 / 39-40 | +12V_PROT / +3V3_PWRBOARD | 0.49 / 0.43 A per 12 V pin at relay pull-in / steady; about 40 mA on 3V3 |
| 24 pins | GND_CTRL | every PWM and analogue pin flanked by ground |
| 7, 9, 11 | RELAY_ON, BIAS_EN, RESET_N | control to power; pull-downs define the state with the control board absent |
| 14, 17 | PWM_H, PWM_L | 100 ohm + 100 pF + 10 k at each driver input; PWM_H -> HS IN+ and LS IN-, PWM_L -> LS IN+ and HS IN- |
| 20, 21, 23, 24, 27, 30, 32, 33 | FLT_H_N, FLT_L_N, RDY_H, RDY_L, OC_N, PG_BIAS_S_N, PG_BIAS_H_N, PG_BIAS_L_N | power to control, open drain, pull-ups on the control board |
| 29, 35, 36, 37 | FAN_TACH, FAULT_N (= ARMED), SPARE_D1, SPARE_D2 | SPARE_D1 has no DSP pin in the baseline (GPIO26 proposed) |
| 43, 45, 47, 49 | ISENSE, ISENSE_REF, VIN_SENSE, VOUT_SENSE | single-ended 0-3 V analogue group at the far end |

The link is single-ended by adaptation of the KR-GD-008 exclusion; two records asked for RS-422, which is a recorded human-review conflict (architecture.md section 4).

## 7. PCB implementation - power board

Board `kicad/power_board/AIPE_SiC_Buck_Power.kicad_pcb`, sha256 `b1bb5698194b9aea681cf10ee529eaa77e9510ea0241b889ead7221b86f4f7a2` (build r20d, [routing_iterations_power.md](../verification/routing_iterations_power.md) section 15). Outline 240.00 x 180.00 mm, four 70 um copper layers, 2.000 mm ([layout_metrics_power.md](../verification/engineering_checks/layout_metrics_power.md)). Layer use as designed: F.Cu HF ceramics and the VIN+ / SW / VOUT+ pours with the TO-247-4, film and terminal pads; In1.Cu PGND return under the commutation loop and GND_CTRL under the SELV strip; In2.Cu Kelvin-source pours and parallel bus pours; B.Cu gate pours and driver-island passives ([pcb_stackup.md](../design/pcb_stackup.md) section 1). As built, all ICs sit on F.Cu: the slotted barrier footprints fix both UCC21710 drivers on the barrier line, 14.353 / 14.360 mm from the gate pads, and the SW current runs on the In2 pour ([pcb_rule_review.md](../verification/pcb_rule_review.md) sections 2, 4, 5). Images: [front](pcb_front_power.png), [back](pcb_back_power.png), [3D](pcb_3d_power.png), [layer PDF](pcb_layout_power.pdf), [schematic](schematic_power.pdf).

| Item | Measured on the delivered board | Source |
|---|---|---|
| Placement rules realised | Q1 / Q2 at 28 mm pitch under the LAM 5 D K sink; eight barrier parts on one line at y = 145.0 mm; ISO_BARRIER rule area 0-240 x 140-150 mm on all four layers with 0 copper items; control section to power stage 12.307 mm (>= 9.0) | layout_metrics_power.md; pcb_rule_review.md section 2 |
| HV to SELV, all layers | 9.486 / 11.100 / 11.100 / 12.025 mm (F / In1 / In2 / B) against 9.0 mm; HV to PE 5.000 mm on every layer; HS island to LS island 6.270 / 6.397 / 4.800 / 6.397 mm against 3.0 / 1.0 | layout_metrics_power.md KR-ISO-001 / 002 rows |
| Slots under the barrier parts | 8 non-plated slots 1.200 mm wide (drill tool T12); around-the-end path U1 / U3 g 7.25, e 3.555, path 10.155 mm; U2 / U4 / U5 8.10 / 3.00 / 10.08; U6 / U7 9.10 / 3.195 / 11.119; U10 7.75 / 3.005 / 9.807 - all >= 9.0 mm with e >= 3.0 | [drill-report.rpt](../manufacturing/power_board/drill/drill-report.rpt); layout_metrics_power.md KR-ISO-004 rows |
| Rule set | 45 custom rules in `AIPE_SiC_Buck_Power.kicad_dru` (9.0 mm HV-SELV, 5.0 mm HV-PE, 3.0 / 1.0 mm functional, 39 pin-field exceptions) | rule count read from the file; pcb_rule_review.md section 3 |
| Routing | 237 footprints, 4755 tracks, 606 vias, 36 zones (20 copper zones + 16 rule areas per layout_metrics_power.md; routing_iterations_power.md section 15.2 counts them as 18 copper + 4 heatsink-hole keep-outs + 14 other rule areas), 0 unresolved connections, 12 order trials, 21 rip-up rounds, 523.7 s | [routing_progress_power.json](../verification/routing_progress_power.json) |
| Native DRC | `kicad-cli` 10.0.7, `--schematic-parity --severity-all --refill-zones`: 0 violations / 0 unconnected / 0 parity; manifest [20261011T054445Z-drc-d0914d79](../verification/drc/20261011T054445Z-drc-d0914d79/run.json) on the board hash above | run.json |
| Stored fills without refill | 0 violations / 0 unconnected (diagnostic, 2026-10-11T05:44:49Z) | [stored_zone_fill_check_power.json](../verification/engineering_checks/stored_zone_fill_check_power.json) |
| ERC and netlist | ERC 0 findings on 12 sheets ([20261010T165532Z-erc-02a2619f](../verification/erc/20261010T165532Z-erc-02a2619f/run.json)); model = schematic = board on 648 named pads, 101 nets, 237 components | [netlist_check_power.json](../verification/netlist_check_power.json) |
| Exports | 11 of 11 commands, 35 hashed artifacts; 754 plated and 26 non-plated holes; 3D models missing for L2 / L3 / L4 (LR-35) | [export-manifest.json](../manufacturing/power_board/export-manifest.json); the missing models are named in [step.log](../manufacturing/power_board/logs/step.log) and in LR-35 of [layout_review_findings.json](../verification/layout_review_findings.json); `step_models_complete: false` in [verification-summary.json](../verification/verification-summary.json) |
| Layout metrics | 58 rows: 27 within, 6 exceeding, 25 measured without threshold | layout_metrics_power.md |

The six exceeding rows are: PE-PCB-002 Q2 source pad to the nearest PGND HF-capacitor pad 41.165 mm (C1.2) against <= 15 mm (LR-22, open); PE-PCB-006 VIN_RAW and VOUT_L with 0 vias (THT-joined pours, a checker limitation, LR-30); KR-ISO-002 VIN-PGND and VOUT-PGND 1.950 mm on F.Cu against 3.0 mm (inside the R6 / R10 pin fields, accepted per-footprint exceptions, LR-31); KR-TH-002 HV copper 4.955 mm from the sink courtyard on F.Cu and 0.000 mm on B.Cu against >= 5.0 mm (the PE reference link column, LR-29). Other measured values a reviewer should weigh: LS gate network 84.44 mm of track against 39.94 mm on the HS side (LR-24), SW copper 3660.2 mm2 on all layers, ISENSE / ISENSE_REF 83.8 / 90.1 mm (layout_metrics_power.md). Every power-board iteration is on record: 19 power DRC manifests from 16 violations / 499 unconnected on 2026-10-10 to the passing r20d run, 4 of them passing (counted from the 51 `run.json` files under `verification/drc/`).

## 8. PCB implementation - control board

Board `kicad/control_board/AIPE_SiC_Buck_Control.kicad_pcb`, sha256 `dead06ed18d851542f76d7175ec4a1cfff3fa2ee4a69203e33f15d1d008f1288` (candidate B, iteration 9 of [routing_iterations_control.md](../verification/routing_iterations_control.md)). Outline 120.00 x 80.00 mm, four 35 um layers, 1.600 mm ([layout_metrics_control.md](../verification/engineering_checks/layout_metrics_control.md)). F.Cu and B.Cu carry signals, In1.Cu is one solid GND_CTRL island of 8376.1 mm2 (threshold >= 8000), In2.Cu holds the rail islands 1V9 (779-797 mm2, 37 vias), 3V3 (5200-5215 mm2, 84 vias), 5V (610-625 mm2) and 12V_PROT (1375-1381 mm2; the lower figure of each pair is the review's measurement, the upper the In2.Cu zone area in [layout_metrics_control.md](../verification/engineering_checks/layout_metrics_control.md)); the mezzanine header J8 is on B.Cu at (28.0, 74.0) and mates with the power-board socket J7 to 0.00 mm ([pcb_rule_review.md](../verification/pcb_rule_review.md) sections 8 and 10). Images: [front](pcb_front_control.png), [back](pcb_back_control.png), [3D](pcb_3d_control.png), [layer PDF](pcb_layout_control.pdf), [schematic](schematic_control.pdf).

| Item | Measured on the delivered board | Source |
|---|---|---|
| Routing | 207 footprints, 5995 tracks, 798 vias, 20 zones (15 corridor zones), 0 unresolved, order `span_asc`, 31 rip-up rounds, 1155.4 s; shared router module sha256 `b78a49cc48f2c82656a382e94078d9cb442a54ad4d3e68f7237161798c48c7b3` | [routing_progress_control.json](../verification/routing_progress_control.json) (tracks, vias, zones, order, rounds, time, router hash; the file holds no footprint count); 207 footprints from [netlist_check_control.json](../verification/netlist_check_control.json) |
| Native DRC | same options: 0 / 0 / 0; manifest [20261011T051246Z-drc-f801ed3c](../verification/drc/20261011T051246Z-drc-f801ed3c/run.json) on the board hash above | run.json |
| Stored fills without refill | 0 / 0 | [stored_zone_fill_check_control.json](../verification/engineering_checks/stored_zone_fill_check_control.json) |
| ERC and netlist | ERC 0 findings ([20261010T071810Z-erc-b207ac59](../verification/erc/20261010T071810Z-erc-b207ac59/run.json); the project has 10 schematic sheets per [v1_v2_comparison.md](v1_v2_comparison.md)); model = schematic = board on 667 named pads, 111 nets, 207 components | [netlist_check_control.json](../verification/netlist_check_control.json) |
| Exports | 11 of 11 commands, 35 hashed artifacts; 798 x 0.3 mm plated vias; 3D models missing for U1 / U3 / Y1 (LR-35) | [export-manifest.json](../manufacturing/control_board/export-manifest.json); the missing models are named in [step.log](../manufacturing/control_board/logs/step.log) and in LR-35 of layout_review_findings.json; `step_models_complete: false` in verification-summary.json |
| Layout metrics | 31 rows: 2 within, 2 exceeding, 17 measured without threshold, 10 not measured (power-stage rules with no control-board input) | layout_metrics_control.md |

Both exceeding rows are the PE-PCB-008 DSP bypass proxy: U5 supply pins to the nearest decoupling pad 5.381 mm at pins 93 / 107 (C29 / C31) against <= 5.0 mm, reported once per pin list and once for the 26 bypass capacitors (layout_metrics_control.md). Measured routing-quality items left open: DSP_TRIP_N 224.4 mm / 21 vias, FAULT_N 319.7 mm / 16 vias, OC_N 204.1 mm / 10 vias, ESTOP_N 402.5 mm / 24 vias (LR-32); ADC filter capacitors 6.9-14.8 mm from the DSP pins and ISENSE 122.2 mm against ISENSE_REF 54.5 mm (LR-33) ([optimisation_before_after.md](../verification/optimisation_before_after.md), Pass 2). 32 control DRC manifests are kept, 6 of them passing; the history runs from 39 open connections on 2026-10-10 to 0 (the 39 is recorded in [optimisation_before_after.md](../verification/optimisation_before_after.md) Pass 1 - DRC 0 / 39 / 0, manifest `20261010T104013Z-drc-7a5fd84b` - and in the pcb_rule_review.md header; the table in routing_iterations_control.md begins at 1 open connection, BIAS_EN, 2026-10-10 14:15 UTC; the ten earliest control manifests carry no finding counts in their run.json).

Reproducibility. The delivered control board was generated with `grid_router.py` at sha256 `b78a49cc...`; the power-board convergence changed that shared module afterwards, and it now hashes `c666ba734e5450014c683fafc87b9e4debffc9e4dddba71a28dd0f07416df860`. An earlier regeneration with an intermediate version of the module had reproduced 2 open connections (iteration 6, manifest `20261010T230400Z-drc-a401f5ad`). A regeneration of candidate B with the current module into a scratch directory, recorded in [control_regeneration_check.json](../verification/engineering_checks/control_regeneration_check.json) (diagnostic, 2026-10-11T06:20Z), gave 0 unresolved connections, 5995 tracks / 798 vias / 20 zones / 207 footprints with every geometric item of the delivered board reproduced (0 items only in one board); the file hashes differ (`b87775ea...` against `dead06ed...`) through uuids and timestamps only. Its DRC in a scratch copy of the project reported 0 unconnected / 0 parity and one library-path warning that is a copied-path artefact; the DRC of the bare `.kicad_pcb` without the project files reported 211 findings that the record attributes to the missing `fp-lib-table` and the KiCad default clearance rule, not to the board. The verification evidence for the delivered board remains its own manifest `f801ed3c`.

## 9. Independent review and correction pass

An independent layout-review agent measured both boards against the baseline, the stack-up and the PE-PCB / KR rules ([pcb_rule_review.md](../verification/pcb_rule_review.md); machine-readable [layout_review_findings.json](../verification/layout_review_findings.json), LR-20..LR-35, three blockers). A first review (LR-01..LR-19) of the 2026-10-10 state - power board absent, control board with 39 open connections - had been applied before: 14 applied (LR-02, LR-04 and LR-16 only partially effective; LR-07 with EFUSE_RTN kept at 0.4 mm; LR-13 at 18.0 mm instead of 17.3 mm), LR-10 / LR-14 / LR-15 / LR-17 / LR-18 open ([optimisation_finding_status.json](../verification/optimisation_finding_status.json); pcb_rule_review.md header). The correction pass on the power board (round r20) gives these measured before / after values ([optimisation_before_after.md](../verification/optimisation_before_after.md) Pass 2; dispositions in [optimisation_finding_status_pass2.json](../verification/optimisation_finding_status_pass2.json)):

| Finding | Severity | Before (r19, sha `ae0f05d8...`) | After (r20d, sha `b1bb5698...`) | Status |
|---|---|---|---|---|
| LR-20 stored fills at 0.3 mm clearance | blocker | 499 clearance findings without refill | 0 (rule-aware refill stored in the file) | applied |
| LR-21 HV copper at the four PE-bonded sink holes | blocker | 0.25 mm on In1 / In2 | 5.1 mm (all-layer keep-outs HS1_HOLE_1..4) | applied |
| LR-23 input PGND return neck | blocker | J2 -> Q2.2 In1 neck 4.56 mm | 24.22 mm (J2 moved from (7.5, 129.0) to (23.0, 112.0)) | applied |
| LR-28 SW copper and output PGND | should-fix | SW via group -> L1.1 In2 neck 5.22 mm; 58 PGND vias | 18.48 mm; 90 PGND vias; J4 -> Q2.2 In1 neck 38.53 mm | partly applied |
| LR-25 intake corridor / film spacing | should-fix | C11 / C12 courtyard 18.96 mm from the sink; RV1 8.28 mm; L1 19.41 mm | 20.06 mm; RV1 moved to (165.0, 88.5), 12.03 mm; L1 18.31 mm (board width cannot give both sides 20 mm) | partly applied |
| LR-22 one-sided HF tier | should-fix | Q2.2 -> nearest PGND HF pad 41.17 mm (C1.2) | 41.17 mm | not applied, open |
| LR-24 LS gate loop (7 vias, R41 / TP2 over the SW pour) | should-fix | 84 mm total gate copper | unchanged; attempt r20c left 9 open (DRC 8 / 10 / 0, [20261011T053341Z-drc-ba043c49](../verification/drc/20261011T053341Z-drc-ba043c49/run.json)), reverted | not applied, open |
| LR-26 AMC1311 pairs split across layers | should-fix | VIN pair In2 / F.Cu, VOUT pair B.Cu / In2 | unchanged; same r20c attempt | not applied, open |
| LR-27 mezzanine overhang | should-fix | control board overhangs 54 mm; 2 of 4 standoffs land on the power board | unchanged (mechanical: bracket or shorter board) | not applied, open |
| LR-29 / LR-30 / LR-31 | notes | B.Cu PE link column in the sink courtyard; checker measured the wrong fills; accepted deviations | LR-30 partly (checker now sees rule-aware fills, neck metric added); LR-31 to be recorded as CR-27 | notes |
| LR-32 control trip / fault meanders | should-fix | DSP_TRIP_N 224.4 mm / 21 vias, FAULT_N 319.7 / 16 | unchanged; pinned-routing attempt left DSP_TRIP_N open (0 / 1 / 0, [20261011T051014Z-drc-b9164471](../verification/drc/20261011T051014Z-drc-b9164471/run.json)), reverted | not applied, open |
| LR-33 ADC filter and sense-line routing | should-fix | capacitors 6.9-14.8 mm from the pins | unchanged | not applied, open |
| LR-34 / LR-35 | notes | In2 fragments, antipad slot, net naming; 3D models | unchanged | notes |

The review's own verdicts stand: the power board was "not finished" at r19; its three blockers LR-20, LR-21 and LR-23 are reported closed on r20d by the correction agent's own measurements (optimisation_before_after.md Pass 2: stored-fill findings 499 -> 0, hole-wall distance 0.25 -> 5.1 mm, J2 return neck 4.56 -> 24.22 mm) and by the passing DRC `d0914d79`; the independent reviewer has not re-reviewed r20d (layout_review_findings.json names the r19 board `ae0f05d8...` as its input). The control board was "acceptable for prototype fabrication" with LR-32 and LR-33 as should-fix items (pcb_rule_review.md section 11) - the reviewer's CAD judgement on the control board as reviewed (sha `dead06ed...`, the delivered file), not a fabrication authorisation: [manufacturing/README.md](../manufacturing/README.md) states that no fabrication or assembly order is authorised or implied, and the 17 "before fabrication" rows V2-01..V2-17 of [known_issues.md](../verification/known_issues.md) remain open. None of this is a hardware result.

## 10. Simulation summary

The behavioural ngspice campaign (KiCad-bundled ngspice-46) ran 20 transient runs - 11 open-loop corners and 9 closed-loop runs (eight cascaded-controller transients and one module-PI reference) - plus 4 parasitic cases, cross-checked against an exact switched-model solution over the ten open-loop CCM runs: within 0.15 % on every current, voltage and loss metric except C_in RMS (2.44 %; the exact model has no input filter) and the output ripple vout_pkpk (5.7 %, about 10 mV; the exact model ignores the input-bus ripple); the light-load run is excluded from the cross-check ([simulation_report.md](../simulation/simulation_report.md) sections 1, 4, 5.2; `cross_check_max_abs_deviation_pct_open_loop_ccm_runs` in [campaign_summary.json](../simulation/results/campaign_summary.json)). It shows: inductor ripple 6.51 / 7.35 / 8.03 App at 360 / 400 / 440 V (baseline 6.5 / 7.3 / 8.0), worst 9.30 App and 32.15 A peak at 440 V / 27.5 A / 235 uH; output ripple 0.16-0.22 Vpp; input ripple 3.56-3.97 Vpp; conduction 29.7-29.9 W and dead-time 2.89 W at 400 V / 25 A; 12.5 A steps of -7.74 to +7.80 V recovering in 0.75-0.77 ms; 25 A dumps peaking at 216.2 / 215.8 V below the 230 V OVP; and that a single voltage-loop PI fails the step (-16.2 V, 5.0 ms, 38.5 A above the OC trip), so the inner current loop is required. It does not show switching losses or efficiency, switch-node overshoot (the parasitic deck is an energy-transfer bound; the design-basis statement is L_loop <= 36 nH at 2.5 A/ns for the 90 V allowance), dv/dt, gate behaviour, DESAT / OC / OVP action, thermal limits, EMI or anything that depends on the real firmware (section 10 of the report). Of the 32 event checks, 23 pass, 3 fail - all three in the deliberately failing single-loop PI reference case (excursion, recovery, I_L above the OC trip) - and 6 are recorded as not applicable: the 12.5 A step limits are not applied to the three 25 A dump events, whose limit is the 230 V OVP (`events[*].checks` and `limit_basis` in campaign_summary.json). [v1_v2_comparison.md](v1_v2_comparison.md) section 2.3 reports this as "event 23/32" and names the four affected run / event pairs.

## 11. Knowledge utilisation summary

The knowledge trace holds 91 query entries (74 searches, 11 `--get` record reads, 6 direct reads) and 317 citation rows over 96 distinct ids; of the 273 labelled rows, 114 are direct, 101 adapted, 35 not applicable and 23 human review ([knowledge_utilisation_report.md](knowledge_utilisation_report.md) sections 1, 2.2 and 7; [v1_v2_comparison.md](v1_v2_comparison.md) section 2.2 also lists the 91). Its section 7 audits 24 significant decisions: a knowledge item set the method or a value in 22 of them, a human-review rule was surfaced instead of decided in 10, at least 9 design errors were prevented or exposed before verification (negative turn-off rail, no copied DESAT values, gate-discharge resistor, interlock, latched fault with UVLO lock-out, hardware OC path, bias sharing, slots, NTC not treated as T_J), the verifiers caught 30 knowledge misapplications (12 changed a value, requirement or part), and 9 knowledge items were found wrong, stale or incomplete. The report's judgement is conditional: the knowledge improved the design together with independent verification; alone it would have improved the questions asked and degraded a few answers. Nothing in the knowledge base is simulated or hardware-validated, and none of the 25 knowledge-base proposals in its section 6 has been applied.

## 12. Verification and hand-off

| Check | Result | Evidence |
|---|---|---|
| Whole-example verifier | `PYTHONIOENCODING=utf-8 python -m automation.scripts.verify_sic_buck`: status `passed`, problems `[]`, scope "CAD connectivity, native check currency and export integrity only; hardware unqualified"; 20 simulation runs, 10 research records, 20 verification records; re-run during the writing of this report | [verification-summary.json](../verification/verification-summary.json) |
| Unit tests | 253 tests in 16 modules; after the floorplan amendment ([floorplan_candidates_power.md](floorplan_candidates_power.md), amendment section) the suite is recorded as `Ran 253 tests ... OK (skipped=2)`, 0 failures; the run logs are kept in the orchestrator scratch directory and are not committed, so no test log is in the repository - re-run `python -m unittest discover -s tests` | [v1_v2_comparison.md](v1_v2_comparison.md) section 2.4; [status-v2.md](../../../docs/status-v2.md) |
| ERC | power 0 findings, 12 sheets (`20261010T165532Z-erc-02a2619f`); control 0 findings (`20261010T071810Z-erc-b207ac59`) | `verification/erc/` |
| DRC | power 0 / 0 / 0 (`20261011T054445Z-drc-d0914d79`, sha `b1bb5698...`); control 0 / 0 / 0 (`20261011T051246Z-drc-f801ed3c`, sha `dead06ed...`); 51 manifests kept (19 power, 4 passing; 32 control, 6 passing), failed iterations included | `verification/drc/` |
| Environment | Windows 10.0.26300, Python 3.10.11, KiCad 10.0.7 `kicad-cli` and bundled Python; nothing installed | [environment.md](../verification/environment/environment.md) |

Release and route. This report, [requirements.yaml](../input/requirements.yaml), [design_decisions.json](../design/design_decisions.json), [magnetic_record.json](../components/magnetic_record.json), [known_issues.md](../verification/known_issues.md), [knowledge_utilisation_report.md](knowledge_utilisation_report.md), the `docs/*-v2.md` files and the repository `README.md` carry the label "AI-GENERATED ENGINEERING PROTOTYPE V2 - HUMAN REVIEW REQUIRED"; the generated JSON and markdown records, the design documents, the schematic and board files (title blocks), [manufacturing/README.md](../manufacturing/README.md), v1_v2_comparison.md, pcb_rule_review.md and simulation_report.md carry the variant "AI-GENERATED ENGINEERING PROTOTYPE - V2 - HUMAN REVIEW REQUIRED" (the control-board title block also holds a bare "AI-GENERATED PROTOTYPE" text, and `campaign_summary.json` reads "AI-GENERATED BEHAVIOURAL SIMULATION - V2 - HUMAN REVIEW REQUIRED"). The wording differs; the meaning does not. The release is frozen after this report was finalised by `python -m automation.scripts.freeze_v2`, which runs `verify_sic_buck` first and refuses to freeze on failure, then copies the snapshot under `releases/v2/` (`README.md`, `SHA256SUMS.json` whose `source_commit` names the commit it was taken from) and writes `releases/v2-review-package.zip`; the snapshot must never be edited ([reproduce-v2.md](../../../docs/reproduce-v2.md), Release; [known_issues.md](../verification/known_issues.md) V2-49). The pull request goes from the fork `MrCoconut616/AIPE-PCB-Agent`, branch `feat/sic-buck-5kw-v2`, to `FulongLi/AIPE-PCB-Agent` `main` with the title "AIPE-PCB-Agent V2 — Knowledge-Driven 5kW SiC Buck" ([requirements.yaml](../input/requirements.yaml) records it with an ASCII hyphen); it is not merged automatically. V1 (`examples/buck-48v-24v-1kw`) is frozen and untouched.

What a reviewer should do first: read the authoritative open-items register [known_issues.md](../verification/known_issues.md) (49 rows V2-01..V2-49 in four groups: before fabrication 17 rows, before energisation 16, before design release 7, documentation and tooling 9); then (1) read [pcb_rule_review.md](../verification/pcb_rule_review.md) and the Pass 2 tables of [optimisation_before_after.md](../verification/optimisation_before_after.md), then decide LR-22, LR-24, LR-26 and LR-27 on the power board and LR-32, LR-33 on the control board; (2) re-run the verifier and recompute the two board hashes against the DRC manifests; (3) close the human-review items that no layout can settle - the impulse basis (4 kV versus 2.5 kV) and the 9.0 mm rule, the PELV bond (A-23), the pad rating (CR-13), the OTP ladder (CR-25), the DESAT margin and destructive short-circuit test (KR-GD-004, KR-PR-001), the bias-module COM-VEE configuration (CR-12) and the single-ended mezzanine ([assumptions.md](../design/assumptions.md) section 7; [knowledge_utilisation_report.md](knowledge_utilisation_report.md) section 8.2); (4) treat `manufacturing/` as a review bundle, not a fabrication order ([README](../manufacturing/README.md)).

## 13. Test points

Power board, from [circuit_power.json](../design/circuit_power.json) (13 parts of kind TP; TP1 / TP2 are two-pin probe loops on B.Cu at the devices, TP3-TP13 are bare 2.0 mm pads on the SELV strip per pcb_rule_review.md section 8):

| Ref | Net(s) | Purpose (model note) |
|---|---|---|
| TP1 | G_H, KS_H | V_GS probe loop at the device side of R_G (CR-11); floats at the switch node - HV referenced, isolated probe only |
| TP2 | G_L, KS_L | V_GS probe loop at the device side of R_G (CR-11); HV referenced, isolated probe only |
| TP3 | 3V3 | SELV test pad, bare PCB (no purchased part) |
| TP4, TP5 | GND_CTRL | SELV test pads, bare PCB |
| TP6 | PWM_H_F | SELV test pad, bare PCB (net name read as the RC-filtered PWM_H at the driver input - inferred, not stated in the model) |
| TP7 | PWM_L_F | SELV test pad, bare PCB (same inference for PWM_L) |
| TP8 | FAULT_N | SELV test pad, bare PCB; FAULT_N = ARMED from the latch Q, indicator / test point only (architecture.md, mezzanine pin 35) |
| TP9 | ISENSE | SELV test pad |
| TP10 | VIN_SENSE | SELV test pad |
| TP11 | VOUT_SENSE | SELV test pad |
| TP12 | SPARE_D1 | A-P9: spare mezzanine line terminated on a test pad |
| TP13 | SPARE_D2 | A-P9: spare mezzanine line terminated on a test pad |

Control board, from [circuit_control.json](../design/circuit_control.json) (16 parts of kind TP, all bare 2.0 mm pads; the model note on each says that ARMED is the FAULT_N net, so ARM, FAULT_LATCH_N and GATE_EN are probed instead of a duplicate):

| Ref | Net | Purpose (the model note is the same for all 16; the function column is read from the net name against architecture.md sections 2.5 and 6) |
|---|---|---|
| TP1, TP2, TP3, TP4 | 3V3, 1V9, 5V, 12V_PROT | supply rails |
| TP5, TP6 | GND_CTRL | ground reference for probes |
| TP7, TP8 | PWM_H, PWM_L | gated PWM to the mezzanine (pins 14 / 17) |
| TP9 | FAULT_N | latch Q = ARMED (architecture.md section 6) |
| TP10 | ARM | latch clock from GPIO2 (architecture.md section 6) |
| TP11 | FAULT_LATCH_N | latched-fault bus (inferred: the AND-combined CLR_N of the latch) |
| TP12 | GATE_EN | PWM run-permit enable (inferred from the net name) |
| TP13 | XRS_N | DSP reset line (firmware_interface.md section 1) |
| TP14, TP15, TP16 | VIN_SENSE, VOUT_SENSE, ISENSE | analogue inputs from the mezzanine (pins 47 / 49 / 43) |

There are no HV test points on either board; HV probing is limited to the two isolated-probe loops TP1 / TP2 (pcb_rule_review.md section 8).

## 14. What is and is not demonstrated

Demonstrated, by files in this example: a complete design record with 26 recorded conflict resolutions and 19 passing calculation invariants; two schematics at zero ERC findings; two placed and routed boards whose pad-to-net connectivity matches the schematic and the model exactly and whose native DRC - with schematic parity, all severities and refilled zones - is zero, and whose stored zone fills, checked separately without refill and without schematic parity (copper only, a diagnostic), are also at zero findings; a 9.0 mm all-layer HV-to-SELV separation, a copper-free barrier strip and slotted barrier packages measured on the delivered board; a behavioural simulation that reproduces the analytical ripple, RMS and conduction figures; and a knowledge trace in which every applicability claim can be challenged. Not demonstrated: any switching, thermal, EMI, insulation or protection behaviour (no hardware exists, no device-physics simulation was run, no double-pulse, short-circuit or type test has been done); the commutation-loop and gate-loop quality that LR-22, LR-24 and LR-26 leave open; the mezzanine mechanics (LR-27); the control-board protection-line routing (LR-32 / LR-33); closed-loop operation (no firmware); a byte-identical control-board file from the current router module (the geometry was reproduced, the uuids were not); and every human-review decision listed in section 12 and in [known_issues.md](../verification/known_issues.md). This document authorises no fabrication, purchase or energisation.
